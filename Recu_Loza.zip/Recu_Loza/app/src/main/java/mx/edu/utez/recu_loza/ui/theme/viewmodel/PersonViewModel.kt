package mx.edu.utez.recu_loza.ui.theme.viewmodel

import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel
import mx.edu.utez.recu_loza.model.Person

class PersonViewModel : ViewModel() {

    val peopleList = mutableStateListOf<Person>()

    init {
        peopleList.addAll(
            listOf(
                Person("Juan", "Pérez", 30, "Masculino", "Soltero"),
                Person("María", "García", 28, "Femenino", "Casada"),
                Person("Luis", "López", 45, "Masculino", "Casado")
            )
        )
    }
}
