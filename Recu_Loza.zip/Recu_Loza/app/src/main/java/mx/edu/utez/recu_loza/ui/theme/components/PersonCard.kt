package mx.edu.utez.recu_loza.ui.theme.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import mx.edu.utez.recu_loza.model.Person

@Composable
fun PersonCard(person: Person) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {

            Text("Nombre: ${person.nombre} ${person.apellido}",
                style = MaterialTheme.typography.titleMedium)

            Spacer(modifier = Modifier.height(4.dp))

            Text("Edad: ${person.edad}", style = MaterialTheme.typography.bodyMedium)
            Text("Sexo: ${person.sexo}", style = MaterialTheme.typography.bodyMedium)
            Text("Estado Civil: ${person.estadoCivil}", style = MaterialTheme.typography.bodyMedium)
        }
    }
}
