package mx.edu.utez.recu_loza.model

data class Person(
    val nombre: String,
    val apellido: String,
    val edad: Int,
    val sexo: String,
    val estadoCivil: String
)
